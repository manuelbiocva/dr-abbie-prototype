# -*- coding: utf-8 -*-
"""Derive the V6 location page from the V5 location structure.

Same sections; restyled into the ClinicPlus composition — inset hero panel,
a clinic facts panel in place of the reference's appointment form, squared
6px geometry, and the three-up contact tiles.
"""
import io
import re

src = io.open('v5-location.main.html', encoding='utf-8').read()
v6 = src

# ------------------------------------------------------------------ HERO
OLD_HERO = re.search(r'  <section class="hero hex-texture">.*?\n  </section>\n', v6, re.S)
assert OLD_HERO, 'hero not found'

NEW_HERO = '''  <section class="hero">
    <div class="container">
      <div class="hero__panel">
        <div class="hero__inner">
          <div class="hero__copy">
            <nav class="crumbs" aria-label="Breadcrumb" style="color:var(--slate)">
              <a href="index.html" style="color:var(--azure-deep)">Home</a><span>/</span><a href="locations.html" style="color:var(--azure-deep)">Clinics</a><span>/</span>Kirrawee
            </nav>
            <h1>Podiatrist in <strong>Kirrawee</strong></h1>
            <div class="hero__card">
              Our head office on Monro Ave, where custom orthotics are made on site. Full
              biomechanical assessment for heel pain, forefoot pain, sports injuries and
              children&rsquo;s feet.
              <a class="btn btn--book" href="#" data-track="book" data-location="kirrawee" data-source="v6-location-hero">Book at Kirrawee</a>
            </div>
          </div>

          <div class="hero__media">
            <span class="hero__badge">
              <span class="rating__stars" aria-hidden="true">
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="m10 1 2.6 5.3 5.9.9-4.3 4.2 1 5.8L10 14.5 4.8 17.2l1-5.8L1.5 7.2l5.9-.9z"/></svg>
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="m10 1 2.6 5.3 5.9.9-4.3 4.2 1 5.8L10 14.5 4.8 17.2l1-5.8L1.5 7.2l5.9-.9z"/></svg>
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="m10 1 2.6 5.3 5.9.9-4.3 4.2 1 5.8L10 14.5 4.8 17.2l1-5.8L1.5 7.2l5.9-.9z"/></svg>
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="m10 1 2.6 5.3 5.9.9-4.3 4.2 1 5.8L10 14.5 4.8 17.2l1-5.8L1.5 7.2l5.9-.9z"/></svg>
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="m10 1 2.6 5.3 5.9.9-4.3 4.2 1 5.8L10 14.5 4.8 17.2l1-5.8L1.5 7.2l5.9-.9z"/></svg>
              </span>
              <span><strong><span class="placeholder">[RATING]</span></strong>
                <span class="text-small text-muted">Google reviews</span></span>
            </span>
            <img src="assets/img/bento-reception.webp" srcset="assets/img/bento-reception.webp 1x, assets/img/bento-reception@2x.webp 2x" width="560" height="560" alt="Reception at the Dr. Abbie Clinics Kirrawee practice" loading="eager" fetchpriority="high" decoding="async" sizes="(min-width: 960px) 45vw, 100vw">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CLINIC FACTS — the reference puts a form here; this carries the real
       conversion paths and the clinic's own details instead. -->
  <section class="section section--tight">
    <div class="container">
      <div class="tiles">
        <a class="tile" href="tel:+61295454378" data-location="kirrawee">
          <span class="tile__label">Call this clinic</span>
          <span class="tile__go" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 14 14" fill="none"><path d="M3.5 10.5 10.5 3.5M5 3.5h5.5V9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
        </a>
        <a class="tile tile--book" href="#" data-track="book" data-location="kirrawee" data-source="v6-location-tiles">
          <span class="tile__label">Book at Kirrawee</span>
          <span class="tile__go" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 14 14" fill="none"><path d="M3.5 10.5 10.5 3.5M5 3.5h5.5V9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
        </a>
        <a class="tile" href="#visit">
          <span class="tile__label">Hours &amp; parking</span>
          <span class="tile__go" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 14 14" fill="none"><path d="M3.5 10.5 10.5 3.5M5 3.5h5.5V9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
        </a>
      </div>
      <p class="text-small text-muted mt-4"><span class="placeholder">[CLIENT TO PROVIDE — Kirrawee Nookal booking URL]</span></p>
    </div>
  </section>
'''
v6 = v6[:OLD_HERO.start()] + NEW_HERO + v6[OLD_HERO.end():]

# remove the V5 consult band — its job is now done by the tiles above
band = re.search(r'\n  <!-- CONSULT BAND.*?\n  </section>\n', v6, re.S)
if band:
    v6 = v6[:band.start()] + '\n' + v6[band.end():]

# practitioner cards -> V6 doctor-card structure
v6 = v6.replace('<div class="person-card__img person-card__figure">',
                '<div class="doc-card__media doc-card__figure">')
v6 = re.sub(r'<h3>(Dr [^<]+)</h3><span class="person-card__role">([^<]*)</span>\s*'
            r'<p class="person-card__creds">([^<]*)</p>\s*'
            r'<span class="person-card__go">View profile.*?</span>',
            lambda m: ('<div class="doc-card__body"><h3>%s</h3>'
                       '<span class="doc-card__role">%s</span>'
                       '<span class="doc-card__badge">'
                       '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">'
                       '<path d="m5 13 4 4 10-10" stroke="currentColor" stroke-width="2.2" '
                       'stroke-linecap="round" stroke-linejoin="round"/></svg>%s</span></div>'
                       % (m.group(1), m.group(2), m.group(3).split('·')[0].strip()[:40])),
            v6, flags=re.S)
v6 = v6.replace('class="card person-card reveal"', 'class="card reveal"')

# give the visit block an anchor for the tile link
v6 = v6.replace('<section class="section">\n    <div class="container">\n      <div class="section-head section-head--center">\n        <span class="eyebrow">Visiting us</span>',
                '<section class="section" id="visit">\n    <div class="container">\n      <div class="section-head section-head--center">\n        <span class="eyebrow">Visiting us</span>')
v6 = v6.replace('<span class="eyebrow">Visiting us</span>',
                '<span class="eyebrow">Visiting us</span>', 1)
if 'id="visit"' not in v6:
    v6 = v6.replace('<span class="eyebrow">Visiting us</span>',
                    '<span class="eyebrow" id="visit">Visiting us</span>', 1)

v6 = v6.replace('v5-location', 'v6-location')

io.open('v6-location.main.html', 'w', encoding='utf-8').write(v6)

for t in ('div', 'section', 'main', 'a', 'span', 'h2', 'h3', 'p', 'nav'):
    o = len(re.findall(r'<%s[\s>]' % t, v6))
    c = len(re.findall(r'</%s>' % t, v6))
    if o != c:
        print('  MISMATCH %s %d/%d' % (t, o, c))
print('v6-location.main.html written, %d bytes' % len(v6))
print('  doc cards :', v6.count('doc-card__body'))
print('  tiles     :', v6.count('class="tile'))
print('  visit id  :', 'id="visit"' in v6)
