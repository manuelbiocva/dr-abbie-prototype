# -*- coding: utf-8 -*-
"""Add the V6 column and matrix row to compare.html."""
import io
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
p = os.path.join(ROOT, 'compare.html')
s = io.open(p, encoding='utf-8').read()

if 'v6-index.html' in s:
    print('compare.html already has V6')
    raise SystemExit

COL = u'''
    <!-- V6 -->
    <article class="col">
      <div class="col__head">
        <span class="col__id">V6</span>
        <span class="col__name">ClinicPlus Structured</span>
        <p class="col__thesis">Bento stats grid and utility bar from the ClinicPlus kit, in Dr.&nbsp;Abbie colours.</p>
      </div>
      <div class="frame"><div class="frame__inner"><iframe data-src="v6-index.html" title="V6 preview" loading="lazy"></iframe></div></div>
      <div class="col__body">
        <div><h3>Signature moves</h3>
          <ul>
            <li>Utility bar with address, hours and reception line</li>
            <li>Inset rounded hero panel, copy card over a soft gradient</li>
            <li><strong>Bento grid</strong> mixing photography with real statistics</li>
            <li>Four bordered service columns; practitioner filter chips</li>
            <li>Squared 6px geometry throughout</li>
          </ul>
        </div>
        <div class="best"><strong>Best if</strong>You want the most structured, information-forward of the six. The bento grid puts &ldquo;250,000+ patients / since 1990 / 11 clinics&rdquo; in front of the reader without a boxy trust strip.</div>
        <div class="risk"><strong>Risk</strong>The reference closes with an appointment form and a newsletter signup; neither can exist here. Densest of the six, so it reads more corporate than V5.</div>
      </div>
      <div class="col__foot">
        <a class="btn btn--open" href="v6-index.html" target="_blank" rel="noopener">Open full size</a>
        <a class="btn btn--ghost" href="v6-location.html" target="_blank" rel="noopener">Location page</a>
      </div>
    </article>
'''

s = s.replace(u'\n  </div>\n\n  <section class="matrix">', COL + u'\n  </div>\n\n  <section class="matrix">')

s = s.replace(u'<th scope="col">V5 MindCare</th></tr>',
              u'<th scope="col">V5 MindCare</th><th scope="col">V6 ClinicPlus</th></tr>')

ROWS = [
    (u'Conversion surface', u'<span class="dot dot--full"></span>High'),
    (u'Local SEO payload', u'<span class="dot dot--full"></span>High'),
    (u'Distinctiveness', u'<span class="dot dot--half"></span>Medium'),
    (u'Premium / authority feel', u'<span class="dot dot--half"></span>Medium'),
    (u'Warmth / approachability', u'<span class="dot dot--half"></span>Medium'),
    (u'Works on a mid-range phone', u'<span class="dot dot--full"></span>Good'),
    (u'Dependence on client photography', u'<span class="dot dot--full"></span>High'),
    (u'Elementor Free build effort', u'<span class="dot dot--full"></span>Higher &mdash; bento grid'),
]
for label, cell in ROWS:
    i = s.find(u'<th scope="row">%s</th>' % label)
    if i == -1:
        print('row not found:', label)
        continue
    end = s.find(u'</tr>', i)
    s = s[:end] + u'<td>%s</td>' % cell + s[end:]

NOTE = (u'      <li><strong>V6 form note:</strong> the ClinicPlus reference floats an appointment form '
        u'(name, email, department, date) over a photo band, and puts a newsletter signup in the footer. '
        u'Both are rebuilt here as a booking link plus a tracked phone call, because the brief bans '
        u'contact forms sitewide.</li>\n')
s = s.replace(u'    </ul>\n  </section>\n</div>', NOTE + u'    </ul>\n  </section>\n</div>')

s = s.replace(u'@media(min-width:1500px){.grid{grid-template-columns:repeat(5,1fr)}}',
              u'@media(min-width:1500px){.grid{grid-template-columns:repeat(3,1fr)}}')
s = s.replace(u'Five design directions for', u'Six design directions for')
s = s.replace(u'All five use the same brand palette', u'All six use the same brand palette')
s = s.replace(u'<h2>Identical across all five</h2>', u'<h2>Identical across all six</h2>')
s = s.replace(u'all five use the AA-safe CTA orange', u'all six use the AA-safe CTA orange')
s = s.replace(u'rather than five times', u'rather than six times')
s = s.replace(u'Least distinctive of the five.', u'Least distinctive of the six.')
s = s.replace(u'strongest local-SEO payload of the five.', u'strongest local-SEO payload of the six.')

io.open(p, 'w', encoding='utf-8').write(s)
print('compare.html updated, %d bytes' % len(s))
