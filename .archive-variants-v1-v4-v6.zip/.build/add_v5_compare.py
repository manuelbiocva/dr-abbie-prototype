# -*- coding: utf-8 -*-
"""Add the V5 column and matrix row to compare.html."""
import io
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
p = os.path.join(ROOT, 'compare.html')
s = io.open(p, encoding='utf-8').read()

if 'v5-index.html' in s:
    print('compare.html already has V5')
    raise SystemExit

COL = u'''
    <!-- V5 -->
    <article class="col">
      <div class="col__head">
        <span class="col__id">V5</span>
        <span class="col__name">MindCare Editorial</span>
        <p class="col__thesis">Wellness-editorial composition from the MindCare kit, rebuilt in Dr.&nbsp;Abbie colours.</p>
      </div>
      <div class="frame"><div class="frame__inner"><iframe data-src="v5-index.html" title="V5 preview" loading="lazy"></iframe></div></div>
      <div class="col__body">
        <div><h3>Signature moves</h3>
          <ul>
            <li>Oversized two-line headline, 300 weight against 700</li>
            <li>&ldquo;Dial now / Book online&rdquo; consult band on deep blue</li>
            <li>Circular practitioner portraits with pale-blue rings</li>
            <li>12px cards, 100px pills, generous off-white ground</li>
          </ul>
        </div>
        <div class="best"><strong>Best if</strong>You want the calm, premium wellness feel of the reference site without leaving the brand. Softest and most contemporary of the five.</div>
        <div class="risk"><strong>Risk</strong>The reference leans on a display serif (Prata) that the brief&rsquo;s typography spec rules out &mdash; see the note below. It also closes with a booking form, which this site cannot have.</div>
      </div>
      <div class="col__foot">
        <a class="btn btn--open" href="v5-index.html" target="_blank" rel="noopener">Open full size</a>
        <a class="btn btn--ghost" href="v5-location.html" target="_blank" rel="noopener">Location page</a>
      </div>
    </article>
'''

s = s.replace(u'\n  </div>\n\n  <section class="matrix">', COL + u'\n  </div>\n\n  <section class="matrix">')

# Matrix: add a V5 column
s = s.replace(
    u'<th scope="col">V4 Utility</th></tr>',
    u'<th scope="col">V4 Utility</th><th scope="col">V5 MindCare</th></tr>')

ROWS = [
    (u'Conversion surface', u'<span class="dot dot--full"></span>High'),
    (u'Local SEO payload', u'<span class="dot dot--half"></span>Medium'),
    (u'Distinctiveness', u'<span class="dot dot--half"></span>Medium'),
    (u'Premium / authority feel', u'<span class="dot dot--full"></span>High'),
    (u'Warmth / approachability', u'<span class="dot dot--full"></span>High'),
    (u'Works on a mid-range phone', u'<span class="dot dot--full"></span>Good'),
    (u'Dependence on client photography', u'<span class="dot dot--full"></span>High'),
    (u'Elementor Free build effort', u'<span class="dot dot--half"></span>Medium'),
]
for label, cell in ROWS:
    marker = u'<th scope="row">%s</th>' % label
    i = s.find(marker)
    if i == -1:
        print('row not found:', label)
        continue
    end = s.find(u'</tr>', i)
    s = s[:end] + u'<td>%s</td>' % cell + s[end:]

NOTE = u'''      <li><strong>V5 typography note:</strong> the MindCare reference pairs a display serif (Prata) with a geometric sans. The brief specifies Poppins and <code>DESIGN.md</code> rules out serif in this medical UI, so V5 carries the display contrast with Poppins 300 against 700 instead. Switching <code>--font-display</code> to a serif is a one-line change &mdash; and a deliberate deviation from the brief, not an accident.</li>
      <li><strong>V5 form note:</strong> the reference closes with an appointment form (name, email, date, time). That section is rebuilt here as a booking link plus a tracked phone call, because the brief bans contact forms sitewide.</li>
'''
s = s.replace(u'    </ul>\n  </section>\n</div>', NOTE + u'    </ul>\n  </section>\n</div>')

# Five columns rather than four on wide screens
s = s.replace(u'@media(min-width:1100px){.grid{grid-template-columns:repeat(4,1fr)}}',
              u'@media(min-width:1100px){.grid{grid-template-columns:repeat(3,1fr)}}'
              u'@media(min-width:1500px){.grid{grid-template-columns:repeat(5,1fr)}}')
s = s.replace(u'Four design directions for', u'Five design directions for')
s = s.replace(u'All four use the same brand palette', u'All five use the same brand palette')
s = s.replace(u'They differ in structure and density, not in branding — so the choice is about which\n      patient the homepage should serve first, not which one follows the brief.',
              u'They differ in structure and density, not in branding — so the choice is about which\n      patient the homepage should serve first, not which one follows the brief.')
s = s.replace(u'<h2>Identical across all four</h2>', u'<h2>Identical across all five</h2>')
s = s.replace(u'all four use the AA-safe CTA orange', u'all five use the AA-safe CTA orange')
s = s.replace(u'so the chrome lifts into WordPress once rather than four times',
              u'so the chrome lifts into WordPress once rather than five times')
s = s.replace(u'Phone CTAs are azure in every direction.', u'Phone CTAs are azure in every direction.')

io.open(p, 'w', encoding='utf-8').write(s)
print('compare.html updated, %d bytes' % len(s))
